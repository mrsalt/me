// ProgressDialog.cpp : implementation file
//

#include "stdafx.h"
#include "resource.h"
#include "WetupDialog.h"

/*
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
*/

/////////////////////////////////////////////////////////////////////////////
// WetupDialog dialog


WetupDialog::WetupDialog(BOOL *Canceled, const char *iText, 
	const char *TitleBar, const char *CancelText, BOOL SPercent, 
	CWnd* pParent /*=NULL*/, BOOL DParent /*=TRUE*/)
	: CDialog(WetupDialog::IDD, pParent)
{
	CancelPressed = Canceled;
	strcpy(InitText, iText);
	strcpy(TitleBarText, TitleBar);
	if (CancelText != NULL)
		strcpy(CancelButtonText, CancelText);
	else 
		strcpy(CancelButtonText, "Cancel");

	ShowPercent = SPercent;

	*CancelPressed = FALSE;
	
	if ((DisableParent = DParent) && (pParentWnd = pParent) )
		pParent->EnableWindow(FALSE);
	//{{AFX_DATA_INIT(WetupDialog)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


BOOL WetupDialog::OnInitDialog()
{   
	CDialog::OnInitDialog();      // TODO: Add extra initialization here
	
	SetWindowText(TitleBarText);
	PercentDone=0;
	WaterPumped=0;
	SetInfo(InitText);
	if (CancelButtonText)
		((CButton *)GetDlgItem(IDCANCEL))->SetWindowText(CancelButtonText);
	if (!ShowPercent){
		CStatic *percentWindow = (CStatic *) GetDlgItem(IDC_PERCENT);
		percentWindow->ShowWindow(SW_HIDE);
	}
	SetWindowPos(&wndTopMost, 0,0,0,0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOREDRAW );
	Wetup();

	return TRUE;   // return TRUE unless you set the focus to a control
                  // EXCEPTION: OCX Property Pages should return FALSE}
}

void WetupDialog::SetInfo(char *newText){
	
	
	if (PercentDone>99)
	{
		Close();
		return;
	}
	CProgressCtrl *progBox = (CProgressCtrl*)GetDlgItem(IDC_PROGRESS1);
	progBox->SetPos( (int)PercentDone );
	if (ShowPercent){
		CStatic *percentWindow = (CStatic *) GetDlgItem(IDC_PERCENT);
		char percentCStr[4];
		wsprintf(percentCStr,"%i%%",(int)PercentDone);
		percentWindow->SetWindowText(percentCStr);
	}

	if (newText){
		CStatic *nText = (CStatic *) GetDlgItem(IDC_WINDOW_TEXT);
		nText->SetWindowText(newText);
	}
	CTime now= CTime::GetCurrentTime();
	TimeLeft =now-StartTime;
	if (PercentDone!=0)
	{
		TimeLeft=CTimeSpan(0,0,0,(int)(TimeLeft.GetTotalSeconds()*(100/PercentDone-1)));
		CStatic *nText=(CStatic *) GetDlgItem(IDC_TIMELEFT);
		nText->SetWindowText(TimeLeft.Format(" %D Days %H:%M:%S"));
		if (WaterPumped!=0)
		{
			CStatic *nText=(CStatic *) GetDlgItem(IDC_WATERPUMPED);
			char pumped[15];
			wsprintf(pumped,"%i Gallons",(int)WaterPumped);
			nText->SetWindowText(pumped);
			WaterLeft=(100/PercentDone-1)*WaterPumped;
			CStatic *mText=(CStatic *) GetDlgItem(IDC_WATERLEFT);
			wsprintf(pumped,"%i Gallons",(int)WaterLeft);
			mText->SetWindowText(pumped);

		}
		



	}


//	if (WaterLeft!=0)
//	{


/*		int y,z,t;
		for (int x=WaterPumped;x<0;x=x;)
		{
			t=0;
			for(z=x;z>10;t++)
			{
				z=/10;
			}

*/



}

void WetupDialog::Close() 
{
	if (DisableParent && pParentWnd)
		pParentWnd->EnableWindow(TRUE);
	DestroyWindow();
}

void WetupDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(WetupDialog)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(WetupDialog, CDialog)
	//{{AFX_MSG_MAP(WetupDialog)
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// WetupDialog message handlers

void WetupDialog::OnCancel() 
{
	// TODO: Add extra cleanup here
	if(MessageBox("Are you sure you want to cancel?","Cancel?",MB_OKCANCEL)==1)
	{
		*CancelPressed = TRUE;
		Close();
	}

}

void WetupDialog::Wetup() 
{
	StartTime=CTime::GetCurrentTime();
	// TODO: Add your control notification handler code here
	int y;
	y=SetTimer(1,100,NULL);     // no timer callback 
}

void WetupDialog::OnTimer(UINT nIDEvent) 
{
	int x = GetState();
	WaterPumped+=5;
	if (x <= 100)
		SetInfo(0);
	if (x > 99)
		return;
//		KillTimer(1);
	CDialog::OnTimer(nIDEvent);
}


int WetupDialog::GetState()
{
	PercentDone++;
	return (int)PercentDone;
}



