// ILGroupProperties.cpp : implementation file
//

#include "stdafx.h"
#include "lada control module.h"
#include "ILGroupProperties.h"

#include "LADA Control ModuleDoc.h"
#include "InputLocFileInfo.h"
#include "ChooseLocationsDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CILGroupProperties dialog
extern CTimeSpan DataRetrievalFreqTable[10];
extern CTimeSpan DataSaveFreqTable[7];
extern CTimeSpan CreateFileFreqTable[3];
extern CFont smallRussianArial;

CILGroupProperties::CILGroupProperties(CLADAControlModuleDoc * doc, CInputLocFileInfo * ptrILFileInfo, CWnd* pParent /*=NULL*/)
	: CDialog(CILGroupProperties::IDD, pParent)
{
	//{{AFX_DATA_INIT(CILGroupProperties)
	m_SaveData = FALSE;
	m_DataRetrFreq = -1;
	m_GroupName = _T("");
	m_NewILFileFreq = -1;
	m_NIL = 0;
	m_SaveDataFreq = -1;
	//}}AFX_DATA_INIT
	pDoc = doc;
	m_ptrILFileInfo = ptrILFileInfo;
	m_LocList = new int[pDoc->nInputLocations];
	

}

CILGroupProperties::~CILGroupProperties()
{
	delete [] m_LocList;
}

void CILGroupProperties::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CILGroupProperties)
	DDX_Control(pDX, IDC_NEW_ILFILE_FREQ, m_F3);
	DDX_Control(pDX, IDC_SAVE_DATA_FREQ, m_F2);
	DDX_Control(pDX, IDC_DATA_RETRIEVAL_FREQ, m_F1);
	DDX_Check(pDX, IDC_SAVE_DATA, m_SaveData);
	DDX_CBIndex(pDX, IDC_DATA_RETRIEVAL_FREQ, m_DataRetrFreq);
	DDX_Text(pDX, IDC_ILGROUPNAME, m_GroupName);
	DDX_CBIndex(pDX, IDC_NEW_ILFILE_FREQ, m_NewILFileFreq);
	DDX_Text(pDX, IDC_NIL, m_NIL);
	DDX_CBIndex(pDX, IDC_SAVE_DATA_FREQ, m_SaveDataFreq);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CILGroupProperties, CDialog)
	//{{AFX_MSG_MAP(CILGroupProperties)
	ON_BN_CLICKED(IDC_SAVE_DATA, OnSaveData)
	ON_BN_CLICKED(IDC_CHOOSE_ILL_LIST, OnChooseIllList)
	ON_BN_CLICKED(IDC_AVERAGE, OnAverage)
	ON_BN_CLICKED(IDC_ONE_INSTANT, OnOneInstant)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CILGroupProperties message handlers

void CILGroupProperties::OnSaveData() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	GetDlgItem(IDC_TEXT17)->EnableWindow(m_SaveData);
	m_F1.EnableWindow(m_SaveData);
	GetDlgItem(IDC_TEXT18)->EnableWindow(m_SaveData);
	m_F2.EnableWindow(m_SaveData);
	GetDlgItem(IDC_AVERAGE)->EnableWindow(m_SaveData);
	GetDlgItem(IDC_ONE_INSTANT)->EnableWindow(m_SaveData);
	GetDlgItem(IDC_TEXT19)->EnableWindow(m_SaveData);
	m_F3.EnableWindow(m_SaveData);
}

void CILGroupProperties::OnChooseIllList() 
{
	// TODO: Add your control notification handler code here
	if (pDoc->nInputLocations > 0)
	{
		UpdateData(TRUE);
			
		CChooseLocationsDlg getNamesDlg(pDoc->InputLocationNameList, m_LocList, &m_NIL, pDoc->nInputLocations);
		
		if (getNamesDlg.DoModal() == IDOK){
			//m_ptrILFileInfo->SetListInfo(nLocs, Locs);
			UpdateData(FALSE);
		}
		//delete [] Locs;
	}
	else
		MessageBox("Please edit the location list first.","Error",MB_OK);
}

void CILGroupProperties::OnAverage() 
{
	// TODO: Add your control notification handler code here
	m_SaveByAverage = TRUE;
	ShowAverageInstant();
}

void CILGroupProperties::OnOneInstant() 
{
	// TODO: Add your control notification handler code here
	m_SaveByAverage = FALSE;
	ShowAverageInstant();
}

void CILGroupProperties::ShowAverageInstant()
{
	((CButton *)GetDlgItem(IDC_AVERAGE))->SetCheck(m_SaveByAverage);
	((CButton *)GetDlgItem(IDC_ONE_INSTANT))->SetCheck(!m_SaveByAverage);
}

void CILGroupProperties::OnOK() 
{
	// TODO: Add extra validation here
	UpdateData();
	m_ptrILFileInfo->m_Do = m_SaveData;
	m_ptrILFileInfo->m_SaveByAverage = m_SaveByAverage;
	m_ptrILFileInfo->m_Name = m_GroupName;
	m_ptrILFileInfo->m_nLocations = m_NIL;

	delete [] m_ptrILFileInfo->m_Locations;
	m_ptrILFileInfo->m_Locations = new int[m_NIL];
	memcpy(m_ptrILFileInfo->m_Locations,m_LocList, sizeof(int) * m_NIL);

	m_ptrILFileInfo->m_RetrFreq = DataRetrievalFreqTable[m_DataRetrFreq];
	m_ptrILFileInfo->m_WriteDataFreq = DataSaveFreqTable[m_SaveDataFreq];
	m_ptrILFileInfo->m_NewFileFreq = CreateFileFreqTable[m_NewILFileFreq];
			 
	CDialog::OnOK();
}

BOOL CILGroupProperties::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	m_SaveData = m_ptrILFileInfo->m_Do;
	m_SaveByAverage = m_ptrILFileInfo->m_SaveByAverage;
	m_GroupName = m_ptrILFileInfo->m_Name;
	m_NIL = m_ptrILFileInfo->m_nLocations;

	memcpy(m_LocList,m_ptrILFileInfo->m_Locations, sizeof(int) * m_ptrILFileInfo->m_nLocations);

	//m_DataRetrFreq = ;// default value
	//m_SaveDataFreq
	//m_NewILFileFreq
	CString s;
	m_F1.SetFont(&smallRussianArial);
	for (int i = 0; i < 10; i++)
	{
		s.LoadString(IDS_N_DATARETR1 + i);
		m_F1.AddString(s);
		if (m_ptrILFileInfo->m_RetrFreq == DataRetrievalFreqTable[i])
			m_DataRetrFreq = i;
		
	}
	m_F2.SetFont(&smallRussianArial);
	for (i = 0; i < 7; i++)
	{
		s.LoadString(IDS_N_DATASAVE1 + i);
		m_F2.AddString(s);
		if (m_ptrILFileInfo->m_WriteDataFreq == DataSaveFreqTable[i])
			m_SaveDataFreq = i;
	}
	m_F3.SetFont(&smallRussianArial);
	for(i = 0; i < 4; i++){
		s.LoadString(IDS_N_FILETIME1 + i);
		m_F3.AddString(s);
		if (m_ptrILFileInfo->m_NewFileFreq == CreateFileFreqTable[i])
			m_NewILFileFreq = i;
	}

	UpdateData(FALSE);
	OnSaveData();
	ShowAverageInstant();

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
