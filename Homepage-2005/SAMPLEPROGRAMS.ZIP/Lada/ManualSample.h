#if !defined(AFX_MANUALSAMPLE_H__7FB03E21_A9C1_11D4_98EA_00A076801ACD__INCLUDED_)
#define AFX_MANUALSAMPLE_H__7FB03E21_A9C1_11D4_98EA_00A076801ACD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ManualSample.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CManualSample dialog

class CManualSample : public CDialog
{
// Construction
public:
	void SetStrings();
	void finish();
	bool done;
	double* data;
	double GetSaturation(int x, int y);
	void Timer();
	CTime Start;
	double GetValue(int,int);
	CManualSample(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CManualSample)
	enum { IDD = IDD_MANUALTEST };
	CListCtrl	m_cchamber2;
	CListCtrl	m_cchamber1;
	CString	m_mtime;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CManualSample)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CManualSample)
	afx_msg void OnStart();
	virtual BOOL OnInitDialog();
	afx_msg void OnTimer(UINT nIDEvent);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MANUALSAMPLE_H__7FB03E21_A9C1_11D4_98EA_00A076801ACD__INCLUDED_)
