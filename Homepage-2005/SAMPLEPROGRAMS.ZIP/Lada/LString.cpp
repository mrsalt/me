// LString.cpp: implementation of the LString class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "LString.h"


#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
extern int curLanguage;
LString::LString()
{
	filen.SetFilePath("Ladastrings.str");
	cLanguage=0;
	Lfont=new CFont;
	load();

}

LString::~LString()
{

}

void LString::load()
{		
	int x,z;
	CFile file (filen.GetFilePath(), CFile::modeRead);
	CArchive ar( &file, CArchive::load);
	ar >> m_CHARSET;
	ar >> m_FontHeight;
	ar >> m_FontName;
//	Lfont->CreateFont(m_FontHeight,0,0,0,0,0,0,0,m_CHARSET,0,0,0,0,m_FontName);
	ar >> nLanguages;
	LNames=new CString[nLanguages];
	for (x=0;x<nLanguages;x++)
		ar.ReadString(LNames[x]);
	ar >> nStrings;
	Data=new CString[nLanguages*nStrings];
	for (x=0;x<nStrings;x++)
		for (z=0;z<nLanguages;z++)
			ar.ReadString(Data[x+z*(nStrings)]);
	ar.Close();
}



	

CString LString::get(int x)
{
	return Data[x+curLanguage*(nStrings)];

}
