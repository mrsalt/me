// SystemDiagDlg.cpp : implementation file
//

#include "stdafx.h"
#include "LADA Control Module.h"
#include "LADA Control ModuleDoc.h"
#include "InputLocFileInfo.h"
#include "SystemDiagDlg.h"
#include "MinMax.h"

#include "ILGroupProperties.h"
#include "InputLocFileInfo.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern int curLanguage;
extern CString ValueToString(double value, int dplaces=2);

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About


/////////////////////////////////////////////////////////////////////////////
// CSystemDiagDlg dialog

CSystemDiagDlg::CSystemDiagDlg(CLADAControlModuleDoc *doc, CWnd* pParent /*=NULL*/)
	: CDialog(CSystemDiagDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSystemDiagDlg)
	m_wGroup = -1;
	//}}AFX_DATA_INIT
	pDoc = doc;
	values = NULL;
}

CSystemDiagDlg::~CSystemDiagDlg()
{
	if (values)
		delete [] values;

}

void CSystemDiagDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSystemDiagDlg)
	DDX_Control(pDX, IDC_GROUP, m_cGroup);
	DDX_Control(pDX, IDC_DIAGLIST, m_cdiag);
	DDX_CBIndex(pDX, IDC_GROUP, m_wGroup);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CSystemDiagDlg, CDialog)
	//{{AFX_MSG_MAP(CSystemDiagDlg)
	ON_BN_CLICKED(IDC_SAVE, OnSave)
	ON_BN_CLICKED(IDC_SELECT, OnSelect)
	ON_BN_DOUBLECLICKED(1001, OnDoubleclicked1001)
	ON_NOTIFY(NM_DBLCLK, IDC_DIAGLIST, OnDblclkDiaglist)
	ON_BN_CLICKED(IDC_PROPERTIES, OnProperties)
	ON_CBN_SELCHANGE(IDC_GROUP, OnSelchangeGroup)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSystemDiagDlg message handlers

BOOL CSystemDiagDlg::OnInitDialog()
{
	CDialog::OnInitDialog();
	m_cdiag.SetExtendedStyle(LVS_EX_FULLROWSELECT|LVS_EX_GRIDLINES);
	if (pDoc->nILFiles)
	{
		CString a[5];
		a[0]="Location";
		a[1]="Value";
		a[2]="Min";
		a[3]="Max";
		a[4]="Status";
		for (int x=0;x<5;x++)
		{
			m_cdiag.InsertColumn(x,a[x],LVCFMT_LEFT,80);
	//		m_cdiag.SetColumnWidth(x,LVS_AUTOFIT);
		}
		for (x = 0; x < pDoc->nILFiles; x++)
			m_cGroup.AddString( pDoc->m_ILData[x].m_Name );
		m_wGroup = 0;
		fileinfo=&pDoc->m_ILData[m_wGroup];//doc->m_DiagGroup];
		values = new double[fileinfo->m_nLocations];
		load();	
	}
	else
	{
		GetDlgItem(IDC_GROUP)->EnableWindow(FALSE);
		GetDlgItem(IDC_GROUPT)->EnableWindow(FALSE);
		GetDlgItem(IDC_PROPERTIES)->EnableWindow(FALSE);
		GetDlgItem(IDC_DIAGLIST)->EnableWindow(FALSE);
		GetDlgItem(IDC_SAVE)->EnableWindow(FALSE);
	}
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CSystemDiagDlg::OnSave() 
{
	// TODO: Add your control notification handler code here
	
}

void CSystemDiagDlg::OnSelect() 
{
	// TODO: Add your control notification handler code here
	
}

void CSystemDiagDlg::OnOK() 
{
	// TODO: Add extra validation here
	
	CDialog::OnOK();
}

void CSystemDiagDlg::GetValues()
{
	for (int i = 0; i < fileinfo->m_nLocations; i++)
		values[i] = rand() % 50 / 10;
}

void CSystemDiagDlg::load()
{
	m_cdiag.DeleteAllItems();

	values=new double[fileinfo->m_nLocations];
	GetValues();
	for (int x=0;x<fileinfo->m_nLocations;x++)
	{
		m_cdiag.InsertItem(x,pDoc->InputLocationNameList[fileinfo->m_Locations[x]][curLanguage]);
		m_cdiag.SetItemText(x,1,ValueToString(values[x]));
		if (fileinfo->m_HasMinMax)
		{
			m_cdiag.SetItemText(x,2,ValueToString(fileinfo->m_Min[x]));
			m_cdiag.SetItemText(x,3,ValueToString(fileinfo->m_Max[x]));
			m_cdiag.SetItemText(x,4,((values[x]>=fileinfo->m_Min[x]) && (values[x]<=fileinfo->m_Max[x]))?"OK":"FAIL");
		}
	}
	m_cGroup.DeleteString(m_wGroup);
	m_cGroup.AddString( fileinfo->m_Name );
	m_cGroup.SetCurSel( m_wGroup );
	//UpdateData(FALSE);
}

void CSystemDiagDlg::OnDoubleclicked1001() 
{

}

void CSystemDiagDlg::OnDblclkDiaglist(NMHDR* pNMHDR, LRESULT* pResult) 
{
	MinMax dlg(fileinfo,0);
	dlg.DoModal();
	// TODO: Add your control notification handler code here
	
	*pResult = 0;
}

void CSystemDiagDlg::OnProperties() 
{
	// TODO: Add your control notification handler code here
	CInputLocFileInfo fInfo;
	fInfo = *fileinfo;
	CILGroupProperties gDlg(pDoc, &fInfo);
	if (gDlg.DoModal() == IDOK)
	{
		*fileinfo = fInfo;
		load();
		pDoc->SetModifiedFlag();
	}

}

void CSystemDiagDlg::OnSelchangeGroup() 
{
	// TODO: Add your control notification handler code here
	m_wGroup = m_cGroup.GetCurSel();
	fileinfo=&pDoc->m_ILData[m_wGroup];//doc->m_DiagGroup];
	load();
}
