// LString.h: interface for the LString class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_LSTRING_H__5C7EC1C0_A5BD_11D4_8BFB_0020781F78D7__INCLUDED_)
#define AFX_LSTRING_H__5C7EC1C0_A5BD_11D4_8BFB_0020781F78D7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class LString  
{
public:
	CFont* Lfont;
	CString get(int);
	CFile filen;
	void load();
	CString* Data;
	CString* LNames;
	int m_nStrings;
	int m_FontHeight;
	int m_CHARSET;
	CString m_FontName;
	int nLanguages;
	int nStrings;
	int cLanguage;
	LString();
	virtual ~LString();

};

#endif // !defined(AFX_LSTRING_H__5C7EC1C0_A5BD_11D4_8BFB_0020781F78D7__INCLUDED_)
