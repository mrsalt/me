// MinMax.cpp : implementation file
//

#include "stdafx.h"
#include "lada control module.h"
#include "MinMax.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// MinMax dialog


MinMax::MinMax(CInputLocFileInfo* file,int num,CWnd* pParent /*=NULL*/)
	: CDialog(MinMax::IDD, pParent)
{
	//{{AFX_DATA_INIT(MinMax)
	fileinfo=file;
	number=num;
	m_vmax = 0.0;
	m_vmin = 0.0;
	//}}AFX_DATA_INIT
}


void MinMax::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(MinMax)
	DDX_Text(pDX, IDC_EMAX, m_vmax);
	DDX_Text(pDX, IDC_EMIN, m_vmin);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(MinMax, CDialog)
	//{{AFX_MSG_MAP(MinMax)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// MinMax message handlers
