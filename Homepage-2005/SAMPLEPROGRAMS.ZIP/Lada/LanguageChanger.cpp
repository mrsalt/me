// LanguageChanger.cpp : implementation file
//

#include "stdafx.h"
#include "LanguageChanger.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// LanguageChanger dialog
extern int curLanguage;
extern LString Strings;

LanguageChanger::LanguageChanger(CWnd* pParent /*=NULL*/)
	: CDialog(LanguageChanger::IDD, pParent)
{
	
}


void LanguageChanger::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(LanguageChanger)
	DDX_Control(pDX, IDC_LIST1, m_Languages);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(LanguageChanger, CDialog)
	//{{AFX_MSG_MAP(LanguageChanger)
	ON_LBN_DBLCLK(IDC_LIST1, OnDblclkList1)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// LanguageChanger message handlers

void LanguageChanger::OnOK() 
{

	if (m_Languages.GetCurSel()>=0)
		curLanguage=m_Languages.GetCurSel();
	CDialog::OnOK();
}

BOOL LanguageChanger::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	for (int x=0;x<Strings.nLanguages;x++)
		m_Languages.AddString(Strings.LNames[x]);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void LanguageChanger::OnDblclkList1() 
{
	OnOK();	
}
