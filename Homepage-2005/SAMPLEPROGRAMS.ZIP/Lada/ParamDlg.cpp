// ParamDlg.cpp : implementation file
//

#include "stdafx.h"
#include "LADA Control Module.h"
#include "ParamDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CParamDlg dialog

CParamDlg::CParamDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CParamDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CParamDlg)
	m_airn = 0.0;
	m_airp = 0.0;
	m_fann = 0.0;
	m_fanp = 0.0;
	m_lightn = 0.0;
	m_lightp = 0.0;
	m_watern = 0.0;
	m_waterp = 0.0;
	//}}AFX_DATA_INIT

}

void CParamDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CParamDlg)
	DDX_Text(pDX, IDC_AIRN, m_airn);
	DDX_Text(pDX, IDC_AIRP, m_airp);
	DDX_Text(pDX, IDC_FANN, m_fann);
	DDX_Text(pDX, IDC_FANP, m_fanp);
	DDX_Text(pDX, IDC_LIGHTN, m_lightn);
	DDX_Text(pDX, IDC_LIGHTP, m_lightp);
	DDX_Text(pDX, IDC_WATERN, m_watern);
	DDX_Text(pDX, IDC_WATERP, m_waterp);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CParamDlg, CDialog)
	//{{AFX_MSG_MAP(CParamDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_UNDO, OnUndo)
	ON_BN_CLICKED(ID_UPDATE, OnUpdate)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CParamDlg message handlers

BOOL CParamDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CParamDlg::OnUndo() 
{
	UpdateData(FALSE);
	
}

void CParamDlg::OnUpdate() 
{
	UpdateData(TRUE);
	m_fanp=m_fann;
	m_lightp=m_lightn;
	m_airp=m_airn;
	m_waterp=m_watern;
	UpdateData(FALSE);
	
}

void CParamDlg::OnOK() 
{
	UpdateData(TRUE);
	if (m_airn!=m_airp||m_fann!=m_fanp||m_lightn!=m_lightp||m_waterp!=m_watern)
		if (MessageBox("Save Data","Save", MB_OKCANCEL)==1)
		{
			OnUpdate();
		}

	MessageBox("OK","OK",MB_OK);

	
	CDialog::OnOK();
}
