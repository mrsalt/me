// ParamDlg.h : header file
//

#if !defined(AFX_PARAMDLG_H__57466686_A1AE_11D4_8BFB_0020781F78D7__INCLUDED_)
#define AFX_PARAMDLG_H__57466686_A1AE_11D4_8BFB_0020781F78D7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CParamDlg dialog

class CParamDlg : public CDialog
{
// Construction
public:
	CParamDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CParamDlg)
	enum { IDD = IDD_PARAM_DIALOG };
	double	m_airn;
	double	m_airp;
	double	m_fann;
	double	m_fanp;
	double	m_lightn;
	double	m_lightp;
	double	m_watern;
	double	m_waterp;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CParamDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CParamDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnUndo();
	afx_msg void OnUpdate();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PARAMDLG_H__57466686_A1AE_11D4_8BFB_0020781F78D7__INCLUDED_)
