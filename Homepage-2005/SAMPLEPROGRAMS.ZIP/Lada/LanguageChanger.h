#if !defined(AFX_LANGUAGECHANGER_H__9D5D9380_A71E_11D4_8BFB_0020781F78D7__INCLUDED_)
#define AFX_LANGUAGECHANGER_H__9D5D9380_A71E_11D4_8BFB_0020781F78D7__INCLUDED_

#include "LString.h"	// Added by ClassView
#include "Resource.h"
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// LanguageChanger.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// LanguageChanger dialog

class LanguageChanger : public CDialog
{
// Construction
public:
	LanguageChanger(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(LanguageChanger)
	enum { IDD = IDD_LANGUAGE };
	CListBox	m_Languages;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(LanguageChanger)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(LanguageChanger)
	virtual void OnOK();
	virtual BOOL OnInitDialog();
	afx_msg void OnDblclkList1();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_LANGUAGECHANGER_H__9D5D9380_A71E_11D4_8BFB_0020781F78D7__INCLUDED_)
