// LADA Control ModuleView.cpp : implementation of the CLADAControlModuleView class
//

#include "stdafx.h"
#include "LADA Control Module.h"

#include "LADA Control ModuleDoc.h"
#include "LADA Control ModuleView.h"
#include "ChooseTime.h"
#include "CameradialogDlg.h"
#include "WaitTimerInfo.h"

#include "ChangeLocationDlg.h"
#include "InputLocFileInfo.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern void  SetFontText(UINT controlID, UINT stringID, CWnd *window);
extern CCameradialogDlg * cameraDlg;
extern DWORD __stdcall CommWaitTimer(void *lpdata);

void CALLBACK EXPORT ResetTimer(
   HWND hWnd,      // handle of CWnd that called SetTimer
   UINT nMsg,      // WM_TIMER
   UINT nIDEvent,   // timer identification
   DWORD dwTime    // system time
)
{
	//hWnd - not important to me...
	// nIDEvent is important
	CLADAControlModuleView * pView = (CLADAControlModuleView *) CWnd::FromHandle(hWnd);
	
	CLADAControlModuleDoc * pDoc = (CLADAControlModuleDoc *) pView->GetDocument( );

	DWORD timeTo;

	int whichIL;
	
	if (nIDEvent >= FIRST_IL_TIMER && nIDEvent <= LAST_IL_TIMER){
		whichIL = nIDEvent - FIRST_IL_TIMER;
		nIDEvent = GET_IL_DATA;
	}
	if (nIDEvent >= FIRST_IL_SAVE_TIMER && nIDEvent <= LAST_IL_SAVE_TIMER){
		whichIL = nIDEvent - FIRST_IL_SAVE_TIMER;
		nIDEvent = SAVE_IL_DATA;
	}

	switch (nIDEvent){
	case UPDATE_GRAPH_TIMER:
		{
			timeTo = pDoc->dataPlotFreq.GetTotalSeconds() * 1000;
		} break;
	case GET_IL_DATA:
		{
			timeTo = pDoc->m_ILData[whichIL].m_RetrFreq.GetTotalSeconds() * 1000;
		} break;
	case SAVE_IL_DATA:
		{
			timeTo = pDoc->m_ILData[whichIL].m_WriteDataFreq.GetTotalSeconds() * 1000;
		} break;
	case FINAL_STORAGE_TIMER:
		{
			timeTo = pDoc->m_FSInfo.m_WriteDataFreq.GetTotalSeconds() * 1000;
		} break;
	default:
		{
			AfxMessageBox("Error in ResetTimer:  Function called by unidentifiable timer ID.",MB_ICONWARNING);
		}
	}
	pView->KillTimer(nIDEvent);
	pView->SetTimer(nIDEvent,timeTo,NULL);
}

/////////////////////////////////////////////////////////////////////////////
// CLADAControlModuleView

IMPLEMENT_DYNCREATE(CLADAControlModuleView, CFormView)

BEGIN_MESSAGE_MAP(CLADAControlModuleView, CFormView)
	//{{AFX_MSG_MAP(CLADAControlModuleView)
	ON_BN_CLICKED(IDC_BUTTON1, OnButton1)
	ON_BN_CLICKED(IDC_BUTTON2, OnButton2)
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_BUTTON3, OnButton3)
	ON_BN_CLICKED(IDC_BUTTON4, OnButton4)
	ON_BN_CLICKED(IDC_BUTTON5, OnButton5)
	ON_BN_CLICKED(IDC_BUTTON12, OnSetInputLocation)
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CFormView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CFormView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CFormView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CLADAControlModuleView construction/destruction

CLADAControlModuleView::CLADAControlModuleView()
	: CFormView(CLADAControlModuleView::IDD)
{
	//{{AFX_DATA_INIT(CLADAControlModuleView)
	m_T1 = 0;
	m_T2 = 0;
	m_T3 = 0;
	m_Delay = 0;
	m_JTime = 0;
	m_JTimeMax = 0;
	m_KTime = 0;
	m_KTimeMax = 0;
	m_OTime = 0;
	m_OTimeMax = 0;
	m_RTime = 0;
	//}}AFX_DATA_INIT
	// TODO: add construction code here
	ConnectedBMP = new CBitmap;
	NConnectedBMP = new CBitmap;
	ConnectedBMP->LoadBitmap(IDB_CONNECTED);
	NConnectedBMP->LoadBitmap(IDB_NCONNECTED);
	hTimerThread = NULL;
	
}

CLADAControlModuleView::~CLADAControlModuleView()
{
	delete ConnectedBMP;
	delete NConnectedBMP;

}

void CLADAControlModuleView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CLADAControlModuleView)
	DDX_Control(pDX, IDC_TEXT3, m_ConnStatus);
	DDX_Control(pDX, IDC_BUTTON4, m_Button4);
	DDX_Control(pDX, IDC_BUTTON3, m_Button3);
	DDX_Control(pDX, IDC_BUTTON2, m_Button2);
	DDX_Control(pDX, IDC_BUTTON1, m_Button1);
	DDX_Control(pDX, IDC_CR10TIME, m_TimeWnd);
	DDX_Control(pDX, IDC_CONNECTED, m_Connected);
	DDX_Text(pDX, IDC_TW1, m_T1);
	DDX_Text(pDX, IDC_TW2, m_T2);
	DDX_Text(pDX, IDC_TW3, m_T3);
	DDX_Text(pDX, IDC_EDITDELAY, m_Delay);
	DDV_MinMaxDWord(pDX, m_Delay, 0, 2000);
	DDX_Text(pDX, IDC_JTIME, m_JTime);
	DDX_Text(pDX, IDC_JTIMEMAX, m_JTimeMax);
	DDX_Text(pDX, IDC_KTIME, m_KTime);
	DDX_Text(pDX, IDC_KTIMEMAX, m_KTimeMax);
	DDX_Text(pDX, IDC_OTIME, m_OTime);
	DDX_Text(pDX, IDC_OTIMEMAX, m_OTimeMax);
	DDX_Text(pDX, IDC_RETR_TIME, m_RTime);
	//}}AFX_DATA_MAP
}

BOOL CLADAControlModuleView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CFormView::PreCreateWindow(cs);
}

void CLADAControlModuleView::OnInitialUpdate()
{
	CFormView::OnInitialUpdate();
	//GetParentFrame()->RecalcLayout();
	for (int i = 0; i < 6; i++)
		SetFontText(IDC_TEXT1 + i, IDS_LTEXT1 + i, this);
	for (i = 0; i < 4; i++)
		SetFontText(IDC_BUTTON1 + i, IDS_LBUTTON1 + i, this);
	m_Button3.EnableWindow(FALSE);
}
/////////////////////////////////////////////////////////////////////////////
// CLADAControlModuleView printing

BOOL CLADAControlModuleView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CLADAControlModuleView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CLADAControlModuleView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

void CLADAControlModuleView::OnPrint(CDC* pDC, CPrintInfo* /*pInfo*/)
{
	// TODO: add customized printing code here
}

/////////////////////////////////////////////////////////////////////////////
// CLADAControlModuleView diagnostics

#ifdef _DEBUG
void CLADAControlModuleView::AssertValid() const
{
	CFormView::AssertValid();
}

void CLADAControlModuleView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}

CLADAControlModuleDoc* CLADAControlModuleView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CLADAControlModuleDoc)));
	return (CLADAControlModuleDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CLADAControlModuleView message handlers

void CLADAControlModuleView::OnButton1() 
{
	// TODO: Add your control notification handler code here
	// start communication
	CLADAControlModuleDoc * pDoc = (CLADAControlModuleDoc *) GetDocument( );
	if (pDoc->commObject == NULL){
		CWaitCursor wait;
		pDoc->commObject = new CCommOperations(FALSE);
		if (pDoc->commObject->IsConnected() && StartTimerThread()){
			m_Connected.SetBitmap((HBITMAP)ConnectedBMP->m_hObject);
			m_ConnStatus.SetWindowText("Connected");
			m_Button2.EnableWindow(FALSE);
			m_Button3.EnableWindow(TRUE);
		}
		else{
			delete pDoc->commObject;
			pDoc->commObject = NULL;
		}
	}
}

BOOL CLADAControlModuleView::StartTimerThread()
{
	CLADAControlModuleDoc * pDoc = (CLADAControlModuleDoc *) GetDocument( );
	
	if (pDoc->commObject)
	{
		pDoc->InCommMode = TRUE;
		CWaitTimerInfo * waitInfo = new CWaitTimerInfo;
		waitInfo->commObject = pDoc->commObject;
		waitInfo->pDoc = pDoc;
		waitInfo->pView = this;
		waitInfo->InCommMode = &pDoc->InCommMode;

		DWORD dwThreadID;

		if (NULL == (hTimerThread =
				  CreateThread( (LPSECURITY_ATTRIBUTES) NULL,
								0,
								CommWaitTimer,
								(LPVOID) waitInfo,
								0, &dwThreadID )))
		{
			return FALSE;
		}
		else
		{
			// which timers do I need?
			// a timer to gather final storage
			// a timer to gather input locations for file creation
			// as requested by the IL data...
			// a timer to update the graphs - synchronus with 
			// the frequency of the data plotting
			
			// when any of the timers which need input locations for their data
			// functions go off they will set an event that says .. OK ... I want
			// data.  When the data is retrieved by the other thread, it will set 
			// the data gathered event to signaled, and all the functions which are waiting
			// for data to be gathered will execute... :)
			CTime currentTime = CTime::GetCurrentTime();
			DWORD timeTo;
			void (CALLBACK EXPORT* lpfnTimer) (HWND, UINT, UINT, DWORD) = &ResetTimer;
			
			if (pDoc->saveFinalStorage){
				if (pDoc->m_FSInfo.m_LastSaveTime != 0){
					timeTo = (pDoc->m_FSInfo.m_LastSaveTime + pDoc->m_FSInfo.m_RetrFreq - currentTime).GetTotalSeconds() * 1000;
					SetTimer(FINAL_STORAGE_TIMER, timeTo, lpfnTimer);
				}
				else
					SetTimer(FINAL_STORAGE_TIMER, pDoc->m_FSInfo.m_WriteDataFreq.GetTotalSeconds() * 1000, NULL);
			}
			
			if (pDoc->saveLocations){
				
				for (int i = 0; i < pDoc->nILFiles; i++)
				{
					if (pDoc->m_ILData[i].m_LastReadTime != 0){
						timeTo = (pDoc->m_ILData[i].m_LastReadTime + pDoc->m_ILData[i].m_RetrFreq - currentTime).GetTotalSeconds() * 1000;
						SetTimer(FIRST_IL_TIMER + i, timeTo, lpfnTimer);
					}
					else
						SetTimer(FIRST_IL_TIMER + i, pDoc->m_ILData[i].m_RetrFreq.GetTotalSeconds() * 1000, NULL);
					
					if (pDoc->m_ILData[i].m_LastSaveTime != 0){
						timeTo = (pDoc->m_ILData[i].m_LastSaveTime + pDoc->m_ILData[i].m_WriteDataFreq.GetTotalSeconds() - currentTime).GetTotalSeconds() * 1000;
						SetTimer(FIRST_IL_SAVE_TIMER + i, timeTo, lpfnTimer);
					}
					else
						SetTimer(FIRST_IL_SAVE_TIMER + i, pDoc->m_ILData[i].m_WriteDataFreq.GetTotalSeconds() * 1000, NULL);
				}
			}

			SetTimer( UPDATE_GRAPH_TIMER, pDoc->dataPlotFreq.GetTotalSeconds() * 1000, NULL);
			// graph will not show an average... it will show the value at an instant...

			//SetTimer( 1, 991, NULL );
			//THREADID( TalkInfo ) = dwThreadID ;
			//HTHREAD( TalkInfo ) = hCommWatchThread ;
			// assert DTR
			//EscapeCommFunction( COMDEV( TalkInfo ), SETDTR ) ;
			return TRUE;
		}	
	}
	return FALSE;
}



void CLADAControlModuleView::OnButton2() 
{
	// TODO: Add your control notification handler code here
	// Upload program
	CLADAControlModuleDoc * pDoc = (CLADAControlModuleDoc *) GetDocument();
	if (pDoc->commObject == NULL){
		AfxMessageBox("Unable to upload program.\nNo connection with CR10 present.");
		return;
	}
	pDoc->StartCommBlock();
	pDoc->commObject->DownloadProgram();
	pDoc->EndCommBlock();
	
}

void CLADAControlModuleView::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	//CFrameWnd::OnTimer(nIDEvent);
	CLADAControlModuleDoc * pDoc = (CLADAControlModuleDoc *) GetDocument( );
	
	int whichIL = -1;
	if (nIDEvent >= FIRST_IL_TIMER && nIDEvent <= LAST_IL_TIMER){
		whichIL = nIDEvent - FIRST_IL_TIMER;
		nIDEvent = GET_IL_DATA;
	}
	if (nIDEvent >= FIRST_IL_SAVE_TIMER && nIDEvent <= LAST_IL_SAVE_TIMER){
		whichIL = nIDEvent - FIRST_IL_SAVE_TIMER;
		nIDEvent = SAVE_IL_DATA;
	}

	switch (nIDEvent){
	case UPDATE_GRAPH_TIMER:
		{
			//if (pDoc->NewDataExists){
			//	pDoc->UpdateGraphViews();
			//	pDoc->NewDataExists = FALSE;
			//}
		//#ifdef _DEBUG
			int *graphList = new int[pDoc->nInputLocations];
			int j = 0;
			for (int n = 0; n < pDoc->numGraphs; n++)
			{
				for (int i = 0; i < pDoc->nDataGraph[n]; i++)
				{
					graphList[j++] = pDoc->InputLocationList[pDoc->DataIndex[n][i]];
				}
			}
			
			if (j) // if there is anything to graph
			{
				pDoc->RequestLocations(graphList, j);
				delete [] graphList;
				pDoc->AddRequest(GraphRequest);
				//if (pDoc->WaitForNewData())
				//{
				//	pDoc->UpdateGraphViews();
				//
				//}
				//else
				//{
				// time out
				//}
			}
			
			UpdateData();
			pDoc->DelayTime = m_Delay;
			m_T1 = pDoc->ThreadsInFunction;
			m_T2 = pDoc->ThreadsInCommunication;
			m_T3 = pDoc->ThreadsInStartBlock;
			m_RTime = (int)pDoc->RTime;
			UpdateData(FALSE);

		//#endif
		} break;
	case GET_IL_DATA:
		{
			// prepare data arrays...
		
			pDoc->RequestLocations(pDoc->m_ILData[whichIL].m_Locations, pDoc->m_ILData[whichIL].m_nLocations );
			pDoc->AddRequest(CollectRequest,whichIL);

			//ResetEvent( pDoc->NewDataObject ); // and setevent
			//DWORD waitPeriod = 1000 * 60 * 3; // 3 minutes // INFINITE
			//DWORD waitResult = WaitForSingleObject(pDoc->NewDataObject, waitPeriod);
			//if (waitResult == WAIT_TIMEOUT)
			//{
			// we had to wait 3 minutes and the communication ready signal was never set
			// do some error handling routine.
			// reset comm. with CR10?
			//
			//
			//}
			//else
			//{
			//	ThreadsUpdating++;
			//	// now that the data has been gathered, add it to the storage array
			//
			//	ThreadsUpdating--;
			//}

		} break;
	case SAVE_IL_DATA:
		{
			pDoc->AddRequest(WriteRequest,whichIL);
				// write the storage array 
			// what if the data is being gathered now?  How can I wait for get_il_Data to finish?
			//for (int i = 0; i < 50 && ThreadsUpdating; i++)
			//{
			//	Sleep(20);
			//}
			//if (i == 50)
			//{
			//	MessageBox("Program Error.  Cannot save data because it is being updated.","Error");
			//	break;
			//}
			// now write the data
		} break;
	case FINAL_STORAGE_TIMER:
		{
			// just do it... no waiting or requesting


		} break;
	default:
		{
			MessageBox("Error in OnTimer:  Function called by unidentifiable timer ID.","Error",MB_ICONWARNING);
		}
	}
}

void CLADAControlModuleView::OnButton3() 
{
	// TODO: Add your control notification handler code here
	// Break Communication
	CLADAControlModuleDoc * pDoc = (CLADAControlModuleDoc *) GetDocument( );
	KillTimer(1);
	if (pDoc->StopComm())
	{
		m_Connected.SetBitmap((HBITMAP)NConnectedBMP->m_hObject);
		m_ConnStatus.SetWindowText("Not Connected");
		m_Button2.EnableWindow(TRUE);
		m_Button3.EnableWindow(FALSE);
	}
}

void CLADAControlModuleView::OnButton4() 
{
	// TODO: Add your control notification handler code here
	// change cr10 time
	CLADAControlModuleDoc * pDoc = (CLADAControlModuleDoc *) GetDocument( );
	
	if (pDoc->commObject == NULL){
		AfxMessageBox("Unable to change time.\nNo connection with CR10 present.");
		return;
	}
	
	CTime date;
	CTime time;
	CChooseTime timeDlg(&date, &time);
	if (timeDlg.DoModal() == IDOK)
	{
		struct tm* osTime;  // A pointer to a structure containing time 
                    // elements.
		osTime = date.GetLocalTm( NULL );
		pDoc->StartCommBlock();
		pDoc->commObject->ChangeCR10Time(time.GetHour(), time.GetMinute(), 
			time.GetSecond(), osTime->tm_yday + 1, date.GetYear());
		pDoc->EndCommBlock();
	}

}

void CLADAControlModuleView::OnButton5() 
{
	// TODO: Add your control notification handler code here
	cameraDlg->TakePictureNow();
}

void CLADAControlModuleView::OnSetInputLocation() 
{
	// TODO: Add your control notification handler code here
	CLADAControlModuleDoc * pDoc = (CLADAControlModuleDoc *) GetDocument( );
	
	CChangeLocationDlg myDlg( pDoc );
	myDlg.DoModal();
	
}



void CLADAControlModuleView::OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint) 
{
	// TODO: Add your specialized code here and/or call the base class
	// sorry John... I was replacing the files I had updated and it looks like you
	// had updated this one also...
	//MessageBox("Fix Me");
	
}
