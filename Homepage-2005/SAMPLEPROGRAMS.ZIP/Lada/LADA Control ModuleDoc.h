// LADA Control ModuleDoc.h : interface of the CLADAControlModuleDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_LADACONTROLMODULEDOC_H__B5A7CF9F_72B9_11D4_98D9_00A076801ACD__INCLUDED_)
#define AFX_LADACONTROLMODULEDOC_H__B5A7CF9F_72B9_11D4_98D9_00A076801ACD__INCLUDED_

#include "InputLocFileInfo.h"	// Added by ClassView
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

typedef char InputListType[2][30];

class CGraphDoc;
class CCommOperations;
class CInputLocFileInfo;
class CLADAControlModuleView;
//class CInputRequest;
//class List;
#include "List.h"
#include "InputRequest.h"

//template< class NODETYPE > class List; 
//enum RequestType {GraphData,CollectData,WriteData};

class CLADAControlModuleDoc : public CDocument
{
	friend class CGraphDoc;
	friend class CProjectSettingsDlg;
	friend class CLADAControlModuleView;
protected: // create from serialization only
	CLADAControlModuleDoc();
	DECLARE_DYNCREATE(CLADAControlModuleDoc)

	List<CInputRequest> GetLocationRequests;
	List<CInputRequest> WriteLocationRequests;
	BOOL  DocInitialized;
	BOOL InCommMode;
	DWORD RTime;
	DWORD DelayTime;
	int ThreadsInFunction;
	int ThreadsInCommunication;
	int ThreadsInStartBlock;

	//HANDLE NewDataObject;
	HANDLE CommSyncObject;
	HANDLE DataTimer;
	CView * pGraphView[4];
	CView * pGraphButtonView[4];
	//BOOL NewDataExists;
	
	BOOL *graphListModified;
	int numGraphs;
	int curWindow;
	BOOL DoAutoWrap;
// Attributes which were in CGraphDoc
	int *nDataGraph;
	BOOL (*ItemChecked)[15];
	int (*DataIndex)[15];
	
	CPen (*pens)[15];
	COLORREF (*colors)[15];
	CBrush backgroundBrush;
// Attributes which were in CGraphDisplay
	//CPen *pens;
	//COLORREF *colors;
	//CBrush backgroundBrush;
	CPen penThickBlack;
	CPen penThinBlack;
	CPen penThinGray;

// Attributes	
	double * GraphData;
	
	double * tempArray;
	double * newData;
	
	int GraphDataBlockSize;
	int nInputLocations;
	int nFilledPoints;

	int nBackPoints;
	int maxGraphItems;
	int GraphDataPos;
	CTime * PositionTime;
	CTimeSpan dataPlotFreq;
	
	
	
	BOOL saveFinalStorage;
	BOOL saveLocations;


	CString dataFolder;
	CString projectOptionsFile;

	InputListType *InputLocationNameList;
	int *InputLocationList;
	
	// new stuff relating to change of IL save
	int nILFiles;
	CInputLocFileInfo * m_ILData;
	
// Operations
public:
	void OnStartNewDocument();
	BOOL StopComm();
	void InitCommSynchronization();
	void StartCommBlock();
	void EndCommBlock();
	void WriteInputLocations();
	void AddData(double data[], CTime dataTime, BOOL UpdateViews = TRUE);
	double GetDataValue(int whichGraph, int whichData, int Position);
	const char * GetDataName(int whichGraph, int whichData);
	CString GetPositionLabel(int Position);
	void FillWithRandomData();
	void SetLastFile(CString fileName);
	void ToggleData(int whichWindow, int whichButton);
	BOOL IsItemChecked(int whichWindow, int whichButton);

	CCommOperations *commObject;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CLADAControlModuleDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	virtual void OnCloseDocument();
	virtual void DeleteContents();
	virtual BOOL OnOpenDocument(LPCTSTR lpszPathName);
	//}}AFX_VIRTUAL

// Implementation
public:
	void AddGraphData(CTime dataTime);
	

	void CompleteRequests();
	void AddRequest(RequestType r, int whichGroup = 0);
	BOOL WaitForNewData();
	void SetLastLocationList(int LocPos, int LocsToGet);
	BOOL InputLocationsChanged(int LocPos, int LocsToGet);
	void ResetGetLocList();
	void RequestLocations(int *locList, int nLoc);// zero based location index
	int m_nGetLocList;
	int * m_GetLocationList;
	int * m_LastGetLocationList;
	CInputLocFileInfo m_FSInfo;
	COLORREF backgroundBrushColor;
	CString m_PcmciaDefault;
	CString m_FloppyDefault;
	void UpdateGraphViews();
	virtual ~CLADAControlModuleDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CLADAControlModuleDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	int m_LastLocsToGet;
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_LADACONTROLMODULEDOC_H__B5A7CF9F_72B9_11D4_98D9_00A076801ACD__INCLUDED_)
