// ManualSample.cpp : implementation file
//

#include "stdafx.h"
#include "lada control module.h"
#include "ManualSample.h"
#include "Lstring.h"
#include "Ladastrings.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
extern CString ValueToString(double, int=2);
extern LString Strings;
/////////////////////////////////////////////////////////////////////////////
// CManualSample dialog


CManualSample::CManualSample(CWnd* pParent /*=NULL*/)
	: CDialog(CManualSample::IDD, pParent)
{
	//{{AFX_DATA_INIT(CManualSample)
	m_mtime = _T("");
	//}}AFX_DATA_INIT
	data=new double[48];
	for (int x=0;x<48;x++)
		data[x]=0;
}


void CManualSample::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CManualSample)
	DDX_Control(pDX, IDC_CHAMBER2, m_cchamber2);
	DDX_Control(pDX, IDC_CHAMBER1, m_cchamber1);
	DDX_Text(pDX, IDC_MTIME, m_mtime);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CManualSample, CDialog)
	//{{AFX_MSG_MAP(CManualSample)
	ON_BN_CLICKED(IDC_START, OnStart)
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CManualSample message handlers


BOOL CManualSample::OnInitDialog() 
{
	CDialog::OnInitDialog();
	m_cchamber1.InsertColumn(0,Strings.get(IDS_H5));
	m_cchamber1.InsertColumn(1,Strings.get(IDS_H6));
	m_cchamber1.InsertColumn(2,Strings.get(IDS_H7));
	m_cchamber1.InsertColumn(3,Strings.get(IDS_H8));
	m_cchamber2.InsertColumn(0,Strings.get(IDS_H5));
	m_cchamber2.InsertColumn(1,Strings.get(IDS_H6));
	m_cchamber2.InsertColumn(2,Strings.get(IDS_H7));
	m_cchamber2.InsertColumn(3,Strings.get(IDS_H8));
	for (int x=0;x<8;x++)
	{
		m_cchamber1.InsertItem(x,Strings.get(IDS_H5)+" "+ValueToString(double(x),0));
		m_cchamber2.InsertItem(x,Strings.get(IDS_H5)+" "+ValueToString(double(x),0));
	}
/*	m_cchamber1.InsertItem(0,"Probe 1");
	m_cchamber1.InsertItem(1,"Probe 2");
	m_cchamber1.InsertItem(2,"Probe 3");
	m_cchamber1.InsertItem(3,"Probe 4");
	m_cchamber1.InsertItem(4,"Probe 5");
	m_cchamber1.InsertItem(5,"Probe 6");
	m_cchamber1.InsertItem(6,"Probe 7");
	m_cchamber1.InsertItem(7,"Probe 8");
	m_cchamber2.InsertItem(0,"Probe 1");
	m_cchamber2.InsertItem(1,"Probe 2");
	m_cchamber2.InsertItem(2,"Probe 3");
	m_cchamber2.InsertItem(3,"Probe 4");
	m_cchamber2.InsertItem(4,"Probe 5");
	m_cchamber2.InsertItem(5,"Probe 6");
	m_cchamber2.InsertItem(6,"Probe 7");
	m_cchamber2.InsertItem(7,"Probe 8");
	*/
	for (x=0;x<4;x++)
	{
		m_cchamber1.SetColumnWidth(x,LVSCW_AUTOSIZE_USEHEADER);
		m_cchamber2.SetColumnWidth(x,LVSCW_AUTOSIZE_USEHEADER);
	}
	/*m_cchamber1.SetColumnWidth(1,LVSCW_AUTOSIZE_USEHEADER);
	m_cchamber1.SetColumnWidth(2,LVSCW_AUTOSIZE_USEHEADER);
	m_cchamber1.SetColumnWidth(3,LVSCW_AUTOSIZE_USEHEADER);
	m_cchamber2.SetColumnWidth(0,LVSCW_AUTOSIZE_USEHEADER);
	m_cchamber2.SetColumnWidth(1,LVSCW_AUTOSIZE_USEHEADER);
	m_cchamber2.SetColumnWidth(2,LVSCW_AUTOSIZE_USEHEADER);
	m_cchamber2.SetColumnWidth(3,LVSCW_AUTOSIZE_USEHEADER);*/
	m_cchamber1.SetExtendedStyle(LVS_EX_FULLROWSELECT|LVS_EX_GRIDLINES);
	m_cchamber2.SetExtendedStyle(LVS_EX_FULLROWSELECT|LVS_EX_GRIDLINES);
	SetStrings();
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CManualSample::OnStart() 
{
	for (int x=0;x<8;x++)
	{
		data[x]= GetValue(x,0);
		m_cchamber1.SetItemText(x,1,ValueToString(data[x]));
		data[x+24]= GetValue(x,1);
		m_cchamber2.SetItemText(x,1,ValueToString(data[x+24]));
	}
	Start=CTime::GetCurrentTime();
	Timer();
 // no timer callback 

		
}

void CManualSample::OnTimer(UINT nIDEvent) 
{
	static int a=0;
	a++;
	if (a>10)
	{
		finish();
		a=0;
		KillTimer(1);
	}
	CTime now;
	now=CTime::GetCurrentTime();
	CTimeSpan span;
	span=now-Start;
	m_mtime=span.Format("%H:%M:%S");
	//m_mtime=now.Format("%H:%M:%S");
	UpdateData(FALSE);
	CDialog::OnTimer(nIDEvent);
}


double CManualSample::GetValue(int x, int y)
{
	return x+y;

}


void CManualSample::Timer()
{
	int y;
	y=SetTimer(1,1000,NULL);   
}

double CManualSample::GetSaturation(int x, int y)
{
	return data[x+y*24]/data[x+8+y*24];

}

void CManualSample::finish()
{
	for (int x=0;x<8;x++)
	{
		
		data[x+8]= GetValue(x,0);
		m_cchamber1.SetItemText(x,2,ValueToString(data[x]));
		data[x+32]= GetValue(x,1);
		m_cchamber2.SetItemText(x,2,ValueToString(data[x+24]));
		data[x+16]=GetSaturation(x,0);
		m_cchamber1.SetItemText(x,3,ValueToString(data[x+16]));
		data[x+40]=GetSaturation(x,1);
		m_cchamber2.SetItemText(x,3,ValueToString(data[x+40]));
	}

}

void CManualSample::SetStrings()
{
	SetWindowText(Strings.get(IDS_H0));
	GetDlgItem(IDC_TEXT1)->SetWindowText(Strings.get(IDS_H1));
	GetDlgItem(IDC_START)->SetWindowText(Strings.get(IDS_H2));
	GetDlgItem(IDC_TEXT3)->SetWindowText(Strings.get(IDS_H3));
	GetDlgItem(IDC_TEXT4)->SetWindowText(Strings.get(IDS_H4));
	GetDlgItem(IDOK)->SetWindowText(Strings.get(IDS_OK1));

}
